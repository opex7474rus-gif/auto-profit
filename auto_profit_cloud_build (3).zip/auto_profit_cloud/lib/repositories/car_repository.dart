import '../data/database.dart';
import '../models/car.dart';
import '../models/expense.dart';
import '../models/attachment.dart';

class CarRepository {
  final _db = AppDatabase.instance;
  Future<List<Car>> cars({String query = ''}) async { final d = await _db.db; final q = '%${query.trim()}%'; final rows = await d.query('cars', where: query.trim().isEmpty ? null : 'make LIKE ? OR model LIKE ? OR vin LIKE ? OR plate LIKE ?', whereArgs: query.trim().isEmpty ? null : [q,q,q,q], orderBy: 'purchase_date DESC'); return rows.map(Car.fromMap).toList(); }
  Future<int> saveCar(Car car) async { final d = await _db.db; if (car.id == null) return d.insert('cars', car.toMap()..remove('id')); await d.update('cars', car.toMap()..remove('id'), where: 'id=?', whereArgs: [car.id]); return car.id!; }
  Future<void> deleteCar(int id) async => (await _db.db).delete('cars', where: 'id=?', whereArgs: [id]);
  Future<List<Map<String,Object?>>> categories() async => (await _db.db).query('expense_categories', orderBy: 'name');
  Future<int> addCategory(String name) async => (await _db.db).insert('expense_categories', {'name': name.trim()});
  Future<List<Map<String,Object?>>> expenses(int carId) async => (await _db.db).rawQuery('SELECT e.*, c.name category_name FROM expenses e JOIN expense_categories c ON c.id=e.category_id WHERE e.car_id=? ORDER BY e.date DESC, e.id DESC', [carId]);
  Future<int> addExpense(Expense e) async => (await _db.db).insert('expenses', e.toMap()..remove('id'));
  Future<void> deleteExpense(int id) async => (await _db.db).delete('expenses', where:'id=?', whereArgs:[id]);
  Future<double> totalExpenses(int carId) async { final r = await (await _db.db).rawQuery('SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE car_id=?',[carId]); return (r.first['total'] as num).toDouble(); }
  Future<List<Attachment>> attachments(int carId) async => (await _db.db).query('attachments', where:'car_id=?', whereArgs:[carId], orderBy:'id DESC').then((r)=>r.map(Attachment.fromMap).toList());
  Future<int> addAttachment(Attachment a) async => (await _db.db).insert('attachments', a.toMap()..remove('id'));
  Future<void> deleteAttachment(int id) async => (await _db.db).delete('attachments', where:'id=?', whereArgs:[id]);
  Future<Map<String,double>> dashboard() async { final d=await _db.db; final cars=await d.query('cars'); double invested=0,revenue=0,profit=0; for(final r in cars){ final id=r['id'] as int; final p=(r['purchase_price'] as num).toDouble(); final ex=await totalExpenses(id); final sale=r['sale_price']==null?0:(r['sale_price'] as num).toDouble(); invested+=p+ex; revenue+=sale; profit+=sale-(p+ex); } return {'invested':invested,'revenue':revenue,'profit':profit,'cars':cars.length.toDouble()}; }
}
